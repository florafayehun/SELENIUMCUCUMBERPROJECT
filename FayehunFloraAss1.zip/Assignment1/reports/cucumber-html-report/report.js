$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("registration.feature");
formatter.feature({
  "line": 2,
  "name": "BlueskycitadelRegistration",
  "description": "",
  "id": "blueskycitadelregistration",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@run"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Valid User Registration",
  "description": "",
  "id": "blueskycitadelregistration;valid-user-registration",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "I navigate to Blue sky citadel website",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "I enter the first name",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "I enter the last name",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I enter the email address",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "i confirm my email address",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "I choose my gender",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "I choose my age",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "I enter my address",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "I click on the Register button",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "I am registered",
  "keyword": "Then "
});
formatter.match({
  "location": "Registration.i_navigate_to_Blue_sky_citadel_website()"
});
formatter.result({
  "duration": 11489149394,
  "status": "passed"
});
formatter.match({
  "location": "Registration.i_enter_the_first_name()"
});
formatter.result({
  "duration": 252637680,
  "status": "passed"
});
formatter.match({
  "location": "Registration.i_enter_the_last_name()"
});
formatter.result({
  "duration": 133506600,
  "status": "passed"
});
formatter.match({
  "location": "Registration.i_enter_the_email_address()"
});
formatter.result({
  "duration": 255446034,
  "status": "passed"
});
formatter.match({
  "location": "Registration.i_confirm_my_email_address()"
});
formatter.result({
  "duration": 366089657,
  "status": "passed"
});
formatter.match({
  "location": "Registration.i_choose_my_gender()"
});
formatter.result({
  "duration": 103998979,
  "status": "passed"
});
formatter.match({
  "location": "Registration.i_choose_my_age()"
});
formatter.result({
  "duration": 108541360,
  "status": "passed"
});
formatter.match({
  "location": "Registration.i_enter_my_address()"
});
formatter.result({
  "duration": 349636096,
  "status": "passed"
});
formatter.match({
  "location": "Registration.i_click_on_the_Register_button()"
});
formatter.result({
  "duration": 77119494,
  "status": "passed"
});
formatter.match({
  "location": "Registration.i_am_registered()"
});
formatter.result({
  "duration": 1803816,
  "error_message": "cucumber.api.PendingException: TODO: implement me\r\n\tat bindings.Registration.i_am_registered(Registration.java:84)\r\n\tat ✽.Then I am registered(registration.feature:14)\r\n",
  "status": "pending"
});
});