package bindings;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.assertTrue;

public class Registration {

    WebDriver driver;



    @Given("^I navigate to Blue sky citadel website$")
    public void i_navigate_to_Blue_sky_citadel_website() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
         driver.get("http://blueskycitadel.com/test-form-for-bluesky-automation-training/");
        driver.manage().window().maximize();
    }

    @When("^I enter the first name$")
    public void i_enter_the_first_name() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        driver.findElement(By.id("nf-field-26")).sendKeys("Flora");
    }

    @When("^I enter the last name$")
    public void i_enter_the_last_name() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        driver.findElement(By.name("lname")).sendKeys("Fayehun");
    }

    @When("^I enter the email address$")
    public void i_enter_the_email_address() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        driver.findElement(By.id("nf-field-28")).sendKeys("flora.fayehun@yahoo.com");
    }

    @When("^i confirm my email address$")
    public void i_confirm_my_email_address() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        driver.findElement(By.id("nf-field-29")).sendKeys("flora.fayehun@yahoo.com");
    }

    @When("^I choose my gender$")
    public void i_choose_my_gender() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        driver.findElement(By.id("nf-field-30")).sendKeys("female");
    }

    @When("^I choose my age$")
    public void i_choose_my_age() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        driver.findElement(By.xpath("//*[@id=\"nf-field-31-0\"]")).click();
    }

    @When("^I enter my address$")
    public void i_enter_my_address() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       driver.findElement(By.id("nf-field-46")).sendKeys("118B, Cromwell drive, Lagos");
    }

    @When("^I click on the Register button$")
    public void i_click_on_the_Register_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        driver.findElement(By.id("nf-field-37")).click();
    }

    @Then("^I am registered$")
    public void i_am_registered() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

}
